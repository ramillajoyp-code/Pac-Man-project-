class FileManager {
  constructor() {
    this.storageKey = 'lossless-file-compress-files';
    // Dynamically fallback to local IP if running straight from the server build
    this.apiBase = window.location.origin.includes('3000') 
      ? window.location.origin 
      : 'http://127.0.0.1:3000';
  }
  getFiles() {
    try {
      return JSON.parse(localStorage.getItem(this.storageKey)) || [];
    } catch (e) {
      return [];
    }
  }

  getFile(id) {
    return this.getFiles().find(file => file.id === id);
  }

  _write(files) {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(files));
    } catch (e) {
      console.warn("Storage write operation blocked by runtime browser window container rules.");
    }
  }

  calculateStorage() {
    const files = this.getFiles();
    const totalSize = files.reduce((sum, f) => sum + (f.originalSize || 0), 0);
    const compressedSize = files.reduce((sum, f) => sum + (f.compressedSize || 0), 0);
    const savings = totalSize > 0 ? Math.max(0, Math.round((1 - compressedSize / totalSize) * 100)) : 0;
    
    return { totalSize, compressedSize, savings };
  }

  async saveFile(filesArray) {
    const normalInput = Array.isArray(filesArray) ? filesArray : [filesArray];
    const formData = new FormData();
    
    normalInput.forEach(file => {
      formData.append('files', file); 
    });

    // DIRECT INTER-PORT PIPELINE ADDRESS MAP
    const response = await fetch(`${this.apiBase}/api/files/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      throw new Error(payload.error || 'Batch compression upload failed.');
    }

    const entry = await response.json();
    const files = this.getFiles();
    files.unshift(entry);
    this._write(files);
    
    return entry;
  }

  renameFile(id, newName) {
    if (!newName || !newName.trim()) return null;
    const files = this.getFiles();
    const target = files.find(f => f.id === id);
    if (!target) return null;
    
    target.name = newName.trim();
    this._write(files);
    return target;
  }

  async deleteFile(id) {
    try {
      const response = await fetch(`${this.apiBase}/api/files/${id}`, { 
        method: 'DELETE' 
      });
      if (!response.ok) throw new Error('Backend erasure stream drop.');
    } catch (error) {
      console.warn('Backend server down; mutating tracking history fallback matrices locally.', error);
    }

    const files = this.getFiles().filter((entry) => entry.id !== id);
    this._write(files);
    return files;
  }
}